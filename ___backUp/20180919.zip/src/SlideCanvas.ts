import { EventDispatcher } from "./events/EventDispatcher";
import { SlideEditable } from "./__core__/SlideEditable";
import { Slide } from "./__core__/Slide";
import { ImageManager } from "./utils/ImageManager";


declare var $:any;
declare var jsSHA:any;

export class SlideCanvas extends EventDispatcher {

	public slide:SlideEditable;
	private UIsForImage:any[];

	constructor(public obj:any){
		super();

		this.UIsForImage = [
			$("button.fit"),
			$("button.rotateL"),
			$("button.rotateR"),
			$("button.delete"),
			$("button.copyTrans"),
			$("button.pasteTrans"),
			$("button.imageRef"),
			$("button.up"),
			$("button.down")
		];
		$.each(this.UIsForImage, (number, obj:any)=>{
			obj.prop("disabled", true);
		});

		this.obj.addClass("slideCanvas");
		this.slide = new SlideEditable($('<div />').appendTo(this.obj));
		this.slide.addEventListener("select", (any)=>{
			$.each(this.UIsForImage, (number, obj:any)=>{
				obj.prop("disabled", this.slide.selectedImg == null);
			});
		});

		//

		$(".zoomIn").click(() => {
			this.slide.scale *= 1.1;
		});
		$(".showAll").click(() => {
			this.slide.scale = SlideEditable.SCALE_DEFAULT;
		});
		$(".zoomOut").click(() => {
			this.slide.scale /= 1.1;
		});

		$(".cut").click(() => {
			this.slide.cut();
		});
		$(".copy").click(() => {
			this.slide.copy();
		});
		$(".paste").click(() => {
			this.slide.paste();
		});
		
		$(".rotateL").click(() => {
			if(this.slide.selectedImg) {
				this.slide.selectedImg.rotation -= 90;
				this.slide.dispatchEvent(new Event("update"));
			}
		});
		$(".rotateR").click(() => {
			if(this.slide.selectedImg) {
				this.slide.selectedImg.rotation += 90;
				this.slide.dispatchEvent(new Event("update"));
			}
		});
		$(".delete").click(() => {
			if(this.slide.selectedImg) {
				this.slide.removeImage(this.slide.selectedImg);
			}
		});
		$(".copyTrans").click(() => {
			this.slide.copyTrans();
		});
		$(".pasteTrans").click(() => {
			this.slide.pasteTrans();
		});
	
		$(".fit").click(() => {
			this.slide.fitSelectedImage();
		});

		$("label[for='cb_imageRef']").click((e)=>{
			$("input#cb_imageRef").prop("checked", !$("input#cb_imageRef").prop("checked"));
			return false;
		});
		
		$("button.imageRef").click(()=>{
			$("input.imageRef")[0].click();
		});

		$("input.imageRef").on("change",(e)=>{
			var reader = new FileReader();
			reader.addEventListener('load', (e:any) => {
				var imgObj = $('<img src="' + reader.result + '" />');

				var shaObj = new jsSHA("SHA-256","TEXT");
				shaObj.update(reader.result);
 				imgObj.bind("load",()=>{
					imgObj.unbind("load");
					imgObj.ready(()=>{
						if($("input#cb_imageRef").prop("checked")){
							ImageManager.swapImageAll(this.slide.selectedImg.imageId, imgObj);
						}else{
							this.slide.selectedImg.swap(imgObj);
							this.slide.dispatchEvent(new Event("update"));
						}

						$("input.imageRef").val("");
					});
					$("body").append(imgObj);
				});
				imgObj.data("imageId",shaObj.getHash("HEX")); 
			});
			try{
				reader.readAsDataURL(e.target.files[0]);
			}
			catch(err){
				console.log(err);
			}
		});



		$("button.up").click(()=>{
			if(this.slide.selectedImg == null) return;
			this.slide.forwardImage(this.slide.selectedImg);
		});
		$("button.down").click(()=>{
			if(this.slide.selectedImg == null) return;
			this.slide.backwordImage(this.slide.selectedImg);
		});

		$(".close").click(() => {
			this.dispatchEvent(new Event("close"));
		});
		
	}

	//

	initialize(){
		this.slide.initialize();
	}

/* 	setData(aData:any[]){
		this.slide.setData(aData);
	}

	getData():any[]{
		return this.slide.getData();
	} */
}