import {EventDispatcher} from "../events/EventDispatcher";

declare var $:any;

export class ImageManager extends EventDispatcher {

    private static _instance:ImageManager;

/*    public static get instance():ImageManager {
        if (!this._instance) {
            this._instance = new ImageManager();
        }
        return this._instance;
	}*/
	
	public static registImage(id:string, imgObj:any) {
		if(!this._instance) this._instance = new ImageManager();
		this._instance.registImage(id, imgObj);
	}

	public static getImageById(id:string):any {
		if(!this._instance) this._instance = new ImageManager();
		return this._instance.getImageById(id);
	}

	public static addEventListener(type:string, callback:Function, priolity?:number) {
		if(!this._instance) this._instance = new ImageManager();
		this._instance.addEventListener(type,callback,priolity);
	}

	//

	private _imageById:any;

	private constructor(){
		super();
		this._imageById = {};
	}

	public registImage(id:string, imgObj:any) {
		if(this._imageById[id]) return;
		this._imageById[id] = imgObj;
	}

	public getImageById(id:string):any {
		return this._imageById[id];
	}

}