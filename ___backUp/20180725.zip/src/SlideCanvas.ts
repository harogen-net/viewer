import { EventDispatcher } from "./events/EventDispatcher";
import { SlideEditable } from "./__core__/SlideEditable";
import { Slide } from "./__core__/Slide";


declare var $:any;
declare var jsSHA:any;

export class SlideCanvas extends EventDispatcher {

	public slide:SlideEditable;


	constructor(public obj:any){
		super();

		this.obj.addClass("slideCanvas");
		this.slide = new SlideEditable($('<div />').appendTo(this.obj));
		this.slide.addEventListener("select", (any)=>{
			$("button.imageRef").prop("disabled", this.slide.selectedImg == null);
		});

		//

		$(".zoomIn").click(() => {
			this.slide.scale *= 1.1;
		});
		$(".showAll").click(() => {
			this.slide.scale = SlideEditable.SCALE_DEFAULT;
		});
		$(".zoomOut").click(() => {
			this.slide.scale /= 1.1;
		});

		$(".rotateL").click(() => {
			if(this.slide.selectedImg) {
				this.slide.selectedImg.rotation -= 90;
				this.slide.dispatchEvent(new Event("update"));
			}
		});
		$(".rotateR").click(() => {
			if(this.slide.selectedImg) {
				this.slide.selectedImg.rotation += 90;
				this.slide.dispatchEvent(new Event("update"));
			}
		});
		$(".delete").click(() => {
			if(this.slide.selectedImg) {
				this.slide.removeImage(this.slide.selectedImg);
			}
		});
		$(".copyTrans").click(() => {
			this.slide.copyTrans();
		});
		$(".pasteTrans").click(() => {
			this.slide.pasteTrans();
		});
	
		$(".fit").click(() => {
			this.slide.fitSelectedImage();
		});

		$("button.imageRef").click(()=>{
			$("input.imageRef")[0].click();
		});

		$("input.imageRef").on("change",(e)=>{
			var reader = new FileReader();
			reader.addEventListener('load', (e:any) => {
				var imgObj = $('<img src="' + reader.result + '" />');

				 var shaObj = new jsSHA("SHA-256","TEXT");
				shaObj.update(reader.result);
				imgObj.bind("load",()=>{
					imgObj.unbind("load");
					$("body").append(imgObj);
					imgObj.ready(()=>{
						this.slide.selectedImg.swap(imgObj);
						this.slide.dispatchEvent(new Event("update"));
					});
				});
				//imgのjqueryオブジェクトに画像バイナリデータから生成したハッシュ値を固有IDとしてセット
				imgObj.data("imageId",shaObj.getHash("HEX"));
			});
			try{
				reader.readAsDataURL(e.target.files[0]);
			}
			catch(e){
				
			}
		});

		$(".close").click(() => {
			this.dispatchEvent(new Event("close"));
		});
	}

	//

	initialize(){
		this.slide.initialize();
	}

/* 	setData(aData:any[]){
		this.slide.setData(aData);
	}

	getData():any[]{
		return this.slide.getData();
	} */
}