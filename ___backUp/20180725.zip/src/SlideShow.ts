import { EventDispatcher } from "./events/EventDispatcher";
import { Slide } from "./__core__/Slide";

declare var $:any;

export class SlideShow extends EventDispatcher {

	private _isRun:boolean;

	private slides:Slide[];
	private data:any[];
	private index:number;
	private timer:any;

	private interval:number;
	private duration:number;
	private bgColor:string;

	//private readonly RUN_IN_WINDOW:boolean = true;

	constructor(public obj:any){
		super();

		obj.addClass("slideShow");
		document.addEventListener("webkitfullscreenchange",()=>{
			if(document.webkitFullscreenElement){
			}else{
				this.stop();
			}
		});

		$(window).resize(()=>{
			setTimeout(()=>{
				$.each(this.slides, (index:number, slide:Slide) =>{
					slide.updateSize();
				})
			},50);

		});
		
		var closeBtn = $('<button class="close"><i class="fas fa-times"></i></button>').appendTo(obj);
		closeBtn.click(()=>{
			//this.stop();
			this.intialize();
		});
	}

	setUp(slides:Slide[]):void {
		//console.log("setup at slideshow", this._isRun);
		this.intialize();

		this.interval = parseInt($("#interval").val());
		this.duration = parseInt($("#duration").val());
		this.bgColor = $("#bgColor").val();

		var slideIndex:number = 0;
		var lastSlide:Slide = undefined;
		for(var i:number = 0; i < slides.length; i++){
			var slide:Slide = slides[i];
			var slide2:Slide = slide.clone();
			slide2.obj.css("background-color",this.bgColor);

			var datum:any = {};

			if(slide.images.length == 1){
				if(lastSlide){
					//console.log(slide.images[0].imageId, lastSlide.images[0].imageId)
					if(slide.images[0].imageId == lastSlide.images[0].imageId){
						datum.transform = slide.images[0].transform;
						datum.index = this.slides.length - 1;
						datum.keep = true;
					}else{
						datum.index = this.slides.length;
						datum.transform = slide.images[0].transform;
						this.slides.push(slide2);
						this.obj.append(slide2.obj);
					}
				}else{
					datum.index = this.slides.length;
					datum.transform = slide.images[0].transform;
					this.slides.push(slide2);
					this.obj.append(slide2.obj);
				}
				lastSlide = slide;
			}else{
				datum.index = this.slides.length;
				this.slides.push(slide2);
				this.obj.append(slide2.obj);
				lastSlide = undefined;
			}
			this.data.push(datum);
		}

		if(this.data[0].index == this.data[this.data.length - 1].index){
			if(this.slides[this.data[0].index].images.length == 1){
				this.data[0].keep = true;
			}

		}
		//console.log(this.data);
	}

	public intialize():void{
		this._isRun = false;
		clearInterval(this.timer);

		if(!$(".fullscreen").prop("checked")) {
		//if(this.RUN_IN_WINDOW) {
			$("body").removeClass("slideShow");
		}else{
			try{
				document.exitFullscreen(); //HTML5 Fullscreen API仕様
			}catch(e){};
			try{
				document.webkitCancelFullScreen(); //Chrome, Safari, Opera
			}catch(e){};
		}

		if(this.slides){
			$.each(this.slides, (index:number, slide:Slide) =>{
				slide.obj.stop();
				slide.obj.remove();
			});
		}
		this.slides = [];
		this.data = [];
		//$("body").removeClass("slideShow");
	}

	public run():void{
		//console.log("run at slideshow", this._isRun);
		if(this._isRun) return;
		if(this.slides.length == 0) return;

		this._isRun = true;

		if(!$(".fullscreen").prop("checked")) {
		//if(this.RUN_IN_WINDOW) {
			$("body").addClass("slideShow");
		}else{
			this.obj[0].webkitRequestFullScreen();
		}

		if(this.data.length <= 1){
			$.each(this.slides, (index:number, slide:Slide) =>{
				slide.obj.css("opacity", 0);
				slide.updateSize();
				slide.obj.animate({"opacity":1},1000);
			})
			return;
		}

		$.each(this.slides, (index:number, slide:Slide) =>{
			slide.obj.css("opacity", 0);
			slide.updateSize();
		})

		let slideShowFunc = () => {
			var datum:any = this.data[this.index % this.data.length];
			var slide:Slide = this.slides[datum.index];

			if(datum.keep && this.index != 0){
				slide.obj.stop().css({"opacity":1});
				slide.obj.find(".imgWrapper").css("transition", "transform " + (this.duration / 1000) + "s cubic-bezier(.4,0,.7,1)");
				slide.images[0].transform = datum.transform;
			   // },50);
			}else{
				if(slide.images.length == 1){
					slide.obj.find(".imgWrapper").css("transition", "");
					slide.images[0].transform = datum.transform;
				}
				slide.obj.css({
					"z-index": this.index + 100,
					"opacity":0
				});
				slide.obj.animate({"opacity":1},this.duration);
			}

			this.timer = setTimeout(slideShowFunc ,this.interval * slide.durationRatio);
			this.index++;
		};

		this.index = 0;
		this.timer = setTimeout(slideShowFunc, 1000);
	}

	stop():void{
	   // console.log("stop at slideshow", this.timer);
		if(!this._isRun) return;
		this._isRun = false;

		if(!$(".fullscreen").prop("checked")) {
		//if(this.RUN_IN_WINDOW) {
			$("body").removeClass("slideShow");
		}else{
			try{
				document.exitFullscreen(); //HTML5 Fullscreen API仕様
			}catch(e){};
			try{
				document.webkitCancelFullScreen(); //Chrome, Safari, Opera
			}catch(e){};
		}

		clearInterval(this.timer);
		$.each(this.slides, (index:number, slide:Slide) =>{
			slide.obj.stop().css({
				"z-index":0,
				"opacity":1
			});
			slide.obj.find(".imgWrapper").css("transition", "");
		})
	}
	
	//

	get isRun():boolean {
		return this._isRun;
	}
}