export class KeyboardManager {

	private static _instance:KeyboardManager;

	/** インスタンスの取得 */
	public static get instance():KeyboardManager {
	if (!this._instance) {
	  this._instance = new KeyboardManager();
	}

	// 生成済みのインスタンスを返す
	return this._instance;
	}

	public static isDown(code:number):boolean{
		if(!this._instance) KeyboardManager.instance;
		
		return this._instance.input_key_buffer[code] as boolean;
	}

	//

	public input_key_buffer:any[];

	private constructor() {
	this.input_key_buffer = [];

	document.onkeydown = (e)=>{
		this.input_key_buffer[e.keyCode] = true;
	};
	document.onkeyup = (e)=>{
		this.input_key_buffer[e.keyCode] = false;
	};
}
}