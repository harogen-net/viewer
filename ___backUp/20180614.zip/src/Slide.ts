import {Image} from "./Image";
import {EventDispatcher} from "./events/EventDispatcher";

declare var $: any;

export class Slide extends EventDispatcher {
	static slideFromImage(img:Image):Slide {
		var slide = new Slide(0, $('<div />'));
		slide.addImage(img);

		return slide;
	}

	//

	protected images:Image[];
	
	
	public container:any;
	
	private scale_min:number = 0.5;
	private scale_max:number = 3;
	protected scale_base:number = 1;

	protected _scale:number = 1;
	protected _selected:boolean = false;
	
	
	constructor(public id:number, public obj:any){
		super();
		
		this.images = [];

		this.obj.addClass("slide");

		this.container = $('<div class="container" />').appendTo(this.obj);
		this.container.css("width",window.screen.width + "px");
		this.container.css("height",window.screen.height + "px");
		

		if(this.obj.width() == 0 && this.obj.height() == 0){
			this.obj.ready(() => {
				this.updateSize();
			});
		}else {
			this.updateSize();
		}
	}
	
	public addImage(img:Image):Image {
		if(!img) return img;

		if(this.images.indexOf(img) != -1){
			this.images.splice(this.images.indexOf(img), 1);
		}else {
			this.images.push(img);
		}
		
		this.container.append(img.obj);
		
		if(!img.transform){
			this.fitImage(img);
		}
		
		this.dispatchEvent(new Event("update"));
		
		return img;
	}
	public removeImage(img:Image):Image {
		if(!img) return img;
		if(this.images.indexOf(img) != -1){
			this.images.splice(this.images.indexOf(img), 1);
		}
		img.obj.remove();
		
		this.dispatchEvent(new Event("update"));
		
		return img;
	}

	//

	get selected(){return this._selected;}
	set selected(value:boolean){
		this._selected = value;
		(this._selected) ? this.obj.addClass("selected") : this.obj.removeClass("selected");
	}
	
	get scale(){return this._scale;}
	set scale(value:number){
		console.log("init",this._scale, this.scale_base);
		this._scale = value > this.scale_min ? (value < this.scale_max ? value : this.scale_max) : this.scale_min;
		var actualScale:number = this._scale * this.scale_base;
		var containerWidth = window.screen.width * actualScale;
		var containerHeight = window.screen.height * actualScale;
		var defX = -(window.screen.width * (1 - actualScale) / 2) + (this.obj.width() - containerWidth) / 2;
		var defY = -(window.screen.height * (1 - actualScale) / 2) + (this.obj.height() - containerHeight) / 2;
		
		this.container.css("transform","matrix(" + actualScale + ",0,0," + actualScale + "," + defX + "," + defY + ")");
	}
	
	//

	public fitToWidth():void {
		var fitHeight = (this.obj.width() / window.screen.width) * window.screen.height;
		console.log("fitToWidth : ", this.obj.width());
		
		this.obj.height(fitHeight);
		this.scale = this._scale;
	}
	public fitToHeight():void {
		console.log("fitToHeight : ", this.obj.height());
		var fitWidth = (this.obj.height() / window.screen.height) * window.screen.width;
		this.obj.width(fitWidth);
		this.scale = this._scale;
	}
	public updateSize():void {
		this.scale_base = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height);
		console.log(this.obj.width(), this.obj.height(), window.screen.width, window.screen.height, this.scale_base, this._scale);
		this.scale = this._scale;
	}
	
	public fitImage(img:Image):Image {
		var scaleX = window.screen.width / img.width;
		var scaleY = window.screen.height / img.height;
		img.scale = Math.min(scaleX, scaleY);
		img.x = window.screen.width >> 1;
		img.y = window.screen.height >> 1;
		return img;
	}

	//

	get data() {
		var ret:any[] = [];
		$.each(this.images, (index:number,img:Image) => {
			ret.push(img.data);
		});
		
		console.log(ret);
		return ret;
	}
}