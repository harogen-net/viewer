import { Slide } from "./Slide";
import {Image} from "./Image";
import { EventDispatcher } from "./events/EventDispatcher";

declare var $: any;

export class SlideList extends EventDispatcher {
	
	private slides:Slide[];

	private slideShowTimer:any;
	private slideShowIndex:number;


	constructor(public obj:any) {
		super();

		this.obj.addClass("slideList");

		this.slides = [];

		this.obj.on("dragover", (e:any) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			this.obj.addClass("fileOver");
		});
		this.obj.on("dragleave", (e:any) => {
			this.obj.removeClass("fileOver");
		});
		this.obj.on("drop", (e:any) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			this.obj.removeClass("fileOver");

			$.each(e.originalEvent.dataTransfer.files, (index:number, file:any) => {
				var reader = new FileReader();
				reader.addEventListener('load', (e:any) => {

					var imgObj = $('<img src="' + reader.result + '" />');

					imgObj.bind("load",()=>{
						imgObj.unbind("load");
						$("body").append(imgObj);
						imgObj.ready(()=>{
							//this.addImage(new Image(imgObj));

							var slideObj = $('<div />');

							slideObj.appendTo(this.obj);
							console.log("aaa : ",slideObj.height());
							var slide = new Slide(0, slideObj);
							console.log("bbb : ",slideObj.height());
							//var slide:Slide = Slide.slideFromImage(new Image(imgObj));
							slide.fitToHeight();
							slide.addImage(new Image(imgObj));



							slide.updateSize();

							this.slides.push(slide);
							slide.obj.on("click", ()=>{
								slide.selected = !slide.selected;
							});
						})
					});

				});
				reader.readAsDataURL(file);
			});
		});



		$(window).resize(()=>{

			setTimeout(()=>{
				$.each(this.slides, (index:number, slide:Slide) =>{
					slide.updateSize();
				})
				},50);

		});


	}

	setMode(mode:string = ""):void {
		if(mode == "slideShow"){
			this.obj[0].webkitRequestFullScreen();

			if(this.slides.length > 1) this.startSlideShow();
		}


	}

	private startSlideShow(){
		var interval:number = 3000;
		var duration:number = 1000;

		$.each(this.slides, (index:number, slide:Slide) =>{
			slide.obj.css("opacity", 0);
		})

		this.slideShowIndex = 0;
		this.slideShowTimer = setInterval(()=>{
			var slide:Slide = this.slides[this.slideShowIndex];

			slide.obj.css("opacity", 0);
			slide.obj.css("z-index", this.slideShowIndex + 100);
			slide.obj.animate({"opacity":1}, duration);
			this.slideShowIndex++;
			this.slideShowIndex = this.slideShowIndex % this.slides.length;
		},interval);
	}

	private stopSlideShow(){
		clearInterval(this.slideShowTimer);
	}

}