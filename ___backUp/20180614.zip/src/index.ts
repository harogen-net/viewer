declare var $: any;

import {Slide} from "./Slide";
import {SlideEditable} from "./SlideEditable";
import {SlideList} from "./SlideList";
import {Image} from "./Image";

var enforceAspectRatio = true;




let canvas:SlideEditable;

$(function(){
	console.log("init");
	
	var thumbs = new SlideList($(".thumbnails"));
	

	$(".canvas").each((i, obj) => {
		canvas = new SlideEditable(i, $(obj));
 		canvas.addEventListener("update",()=>{
			//console.log("update");
		
		});
		
	});
	
	$(".zoomIn").click(() => {
		canvas.scale *= 1.1;
	});
	$(".showAll").click(() => {
		canvas.scale = SlideEditable.SCALE_DEFAULT;
	});
	$(".zoomOut").click(() => {
		canvas.scale /= 1.1;
	});
	
	$(".rotateL").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation -= 90;
		}
	});
	$(".rotateR").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation += 90;
		}
	});
	$(".delete").click(() => {
		if(canvas.selectedImg) {
			canvas.removeImage(canvas.selectedImg);
		}
	});
	$(".copyTrans").click(() => {
		canvas.copyTrans();
	});
	$(".pasteTrans").click(() => {
		canvas.pasteTrans();
	});
	$(".data").click(() => {
		var data = canvas.data;
	});
	$(".fit").click(() => {
		canvas.fitSelectedImage();
	});

	
	$(".slideShow").click(() => {
		//$("body").toggleClass("slideShow");
		thumbs.setMode("slideShow");
	});
	
	document.addEventListener("webkitfullscreenchange",()=>{
		if(document.webkitFullscreenElement){
			$("body").addClass("slideShow");
		}else{
			$("body").removeClass("slideShow");
		}
	});
	
});




function distance(x1,y1,x2,y2){
	return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	
}