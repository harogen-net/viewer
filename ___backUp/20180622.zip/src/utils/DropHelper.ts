import {EventDispatcher} from "../events/EventDispatcher";
import {IDroppable} from "../interface/IDroppable";

declare var $:any;
declare var jsSHA:any;

export class DropHelper extends EventDispatcher {
	public static readonly EVENT_DROP_COMPLETE:string = "DropHelper.EVENT_DROP_COMPLETE";

    constructor(target:IDroppable){
        super();

        var obj:any = target.obj;

		obj.on("dragover", (e:any) => {
            if(!target.isActive) return;

			e.preventDefault();
			e.stopImmediatePropagation();
			obj.addClass("fileOver");
		});
		obj.on("dragleave", (e:any) => {
            if(!target.isActive) return;

			obj.removeClass("fileOver");
		});
		obj.on("drop", (e:any) => {
            if(!target.isActive) return;
            
			e.preventDefault();
			e.stopImmediatePropagation();
			obj.removeClass("fileOver");

			$.each(e.originalEvent.dataTransfer.files, (index:number, file:any) => {
                var reader = new FileReader();
				reader.addEventListener('load', (e:any) => {
					var imgObj = $('<img src="' + reader.result + '" />');

 					var shaObj = new jsSHA("SHA-256","TEXT");
					shaObj.update(reader.result);
					//var sha256digest = shaObj.getHash("HEX"); 

					imgObj.bind("load",()=>{
						imgObj.unbind("load");
						$("body").append(imgObj);
						imgObj.ready(()=>{
							var e:CustomEvent = new CustomEvent(DropHelper.EVENT_DROP_COMPLETE, {detail:imgObj});
							this.dispatchEvent(e);
                        })
					});
					imgObj.data("imageId",shaObj.getHash("HEX"));
				});
				reader.readAsDataURL(file);
			});
		});

    }


}