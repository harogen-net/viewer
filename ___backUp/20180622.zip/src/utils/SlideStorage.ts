import {Slide} from "../Slide";
import { Image } from "../Image";

declare var $:any;

export class SlideStorage {

    private static readonly SAVE_KEY:string = "viewer.slideData";

    public slides:Slide[];

    constructor() {
    }

    save(slides:Slide[]){
        var json:any = {};

        var slideData:any[] = [];
        $.each(slides, (i:number, slide:Slide)=>{
            var imageData:any[] = [];
            $.each(slide.getData(), (j:number, datum:any)=>{
                imageData.push(datum);
            });
            slideData.push(imageData);
        });
        json.data = slideData;
        var jsonStr:string = JSON.stringify(json);
        
        localStorage.setItem(SlideStorage.SAVE_KEY,jsonStr);
        console.log(slideData);
    }

    load() {
        this.slides = [];

        var jsonStr:string = localStorage.getItem(SlideStorage.SAVE_KEY);
        var json:any = JSON.parse(jsonStr);
        $.each(json.data, (i:number, imageData:any)=>{
//            console.log(imageData);

            var slide:Slide = new Slide($('<div />'));
            $.each(imageData, (j:number, datum:any)=>{
                var imgObj:any = $("<img />");
                imgObj.attr("src",datum.src);
                var img:Image = new Image(imgObj, {
                    transX:datum.transX,
                    transY:datum.transY,
                    scaleX:datum.scaleX,
                    scaleY:datum.scaleY,
                    rotation:datum.rotation
                });
                img.id = datum.id;

                slide.addImage(img);
            });

            this.slides.push(slide);
        });

    }

/*    private makeSlideFromData(data:any):Slide {
        

        return 
    }*/
}