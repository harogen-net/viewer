declare var $: any;

import {Slide} from "./Slide";
import {SlideEditable} from "./SlideEditable";
import {SlideList} from "./SlideList";
import {Image} from "./Image";
import { SlideStorage } from "./utils/SlideStorage";
import { SlideShow } from "./SlideShow";

var enforceAspectRatio = true;
const MODE_SELECT = "mode_select";
const MODE_EDIT = "mode_edit";
const MODE_SLIDESHOW = "mode_slideshow";


let canvas:SlideEditable;
let list:SlideList;
let slideShow:SlideShow;
let storage:SlideStorage;

$(function(){
	console.log("init");
	
	$(document).on("drop dragover", (e:any) => {
		e.preventDefault();
		e.stopImmediatePropagation();
	});

	list = new SlideList($(".list"));
	canvas = new SlideEditable($(".canvas"));
	slideShow = new SlideShow($("<div />").appendTo($("body")));

	storage = new SlideStorage();

	list.addEventListener("select", ()=>{
		//console.log("slide selected at list");
		if(list.selectedSlide){
			canvas.isActive = true;
			list.selectedSlide.isLock = true;
			canvas.setData(list.selectedSlide.getData());
			list.selectedSlide.isLock = false;
		}else{
			canvas.initialize();
		}
	})
	list.addEventListener("edit", ()=>{

	});
	canvas.addEventListener("update",()=>{
		if(list.selectedSlide){
			list.selectedSlide.setData(canvas.getData());
		}
	});
	
	$(".zoomIn").click(() => {
		canvas.scale *= 1.1;
	});
	$(".showAll").click(() => {
		canvas.scale = SlideEditable.SCALE_DEFAULT;
	});
	$(".zoomOut").click(() => {
		canvas.scale /= 1.1;
	});
	
	$(".rotateL").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation -= 90;
			canvas.dispatchEvent(new Event("update"));
		}
	});
	$(".rotateR").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation += 90;
			canvas.dispatchEvent(new Event("update"));
		}
	});
	$(".delete").click(() => {
		if(canvas.selectedImg) {
			canvas.removeImage(canvas.selectedImg);
		}
	});
	$(".copyTrans").click(() => {
		canvas.copyTrans();
	});
	$(".pasteTrans").click(() => {
		canvas.pasteTrans();
	});

	$(".fit").click(() => {
		canvas.fitSelectedImage();
	});

	$(".save").click(()=>{
		storage.save(list.slides);
	});
	$(".load").click(()=>{
		if(window.confirm('load slides. Are you sure?')){
			list.initialize();
			canvas.initialize();
			
			storage.load();
			$.each(storage.slides, (i:number, slide:Slide)=>{
				list.addSlide(slide);
			});
		}
	});

	
	$(".startSlideShow").click(() => {
		//$("body").toggleClass("slideShow");
		//list.setMode(SlideList.MODE_SLIDE_SHOW);
		slideShow.setUp(list.slides);
		slideShow.run();
	});
	
	document.addEventListener("webkitfullscreenchange",()=>{
		if(document.webkitFullscreenElement){
			$("body").addClass("slideShow");
		}else{
			$("body").removeClass("slideShow");
		}
	});
	
});




function distance(x1,y1,x2,y2){
	return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	
}