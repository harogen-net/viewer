import { Slide } from "./Slide";
import {Image} from "./Image";
import { EventDispatcher } from "./events/EventDispatcher";
import { DropHelper } from "./utils/DropHelper";
import { IDroppable } from "./interface/IDroppable";

declare var $: any;

export class SlideList extends EventDispatcher implements IDroppable {
	public static readonly MODE_SLIDE_SHOW:string = "SlideList.slideShow";
	public static readonly MODE_LIST:string = "SlideList.list";

	private _slides:Slide[];

	private slideShowTimer:any;
	private slideShowIndex:number;

	private mode:string = SlideList.MODE_LIST;
	private _selectedSlide:Slide;

	private idBase:number = 1;



	constructor(public obj:any) {
		super();

		this.obj.addClass("slideList");

		this._slides = [];

		var dropHelper = new DropHelper(this);
		dropHelper.addEventListener(DropHelper.EVENT_DROP_COMPLETE, (e:CustomEvent)=>{
			var slideObj = $('<div />');
			var slide = new Slide(slideObj);
			//slide.updateSize();
			this.addSlide(slide);
			slide.addImage(new Image(e.detail));
		});


		/*this.obj.on("dragover", (e:any) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			this.obj.addClass("fileOver");
		});
		this.obj.on("dragleave", (e:any) => {
			this.obj.removeClass("fileOver");
		});
		this.obj.on("drop", (e:any) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			this.obj.removeClass("fileOver");

			$.each(e.originalEvent.dataTransfer.files, (index:number, file:any) => {
				var reader = new FileReader();
				reader.addEventListener('load', (e:any) => {

					var imgObj = $('<img src="' + reader.result + '" />');

					imgObj.bind("load",()=>{
						imgObj.unbind("load");
						$("body").append(imgObj);
						imgObj.ready(()=>{
							//this.addImage(new Image(imgObj));

							var slideObj = $('<div />');
							var slide = new Slide(this.idBase++, slideObj);
							//var slide:Slide = Slide.slideFromImage(new Image(imgObj));
							slide.updateSize();

							this.addSlide(slide);

							slide.addImage(new Image(imgObj));
						})
					});

				});
				reader.readAsDataURL(file);
			});
		});*/



		$(window).resize(()=>{
			setTimeout(()=>{
				$.each(this._slides, (index:number, slide:Slide) =>{
					var bool:boolean = slide.selected;
					slide.selected = false;
					slide.fitToHeight();
					slide.updateSize();
					slide.selected = bool;
				})
			},50);

		});
	}

/* 	setMode(mode:string = ""):void {
		this.mode = mode;
		if(this.mode == SlideList.MODE_SLIDE_SHOW){
			this.obj[0].webkitRequestFullScreen();
			if(this._slides.length > 1) this.startSlideShow();
		}
	} */

	initialize():void {
		while(this.slides.length > 0){
			this.removeSlide(this.slides[0]);
		}
	}


	addSlide(slide:Slide,index:number = -1):Slide {
		if(index != -1 && this._slides.length > index){
			this._slides.splice(index + 1,0,slide);
			$.each(this._slides, (index2:number, slide2:Slide) => {
				this.obj.append(slide2);
			});
			this._slides[index].obj.after(slide.obj);
		}else{
			this._slides.push(slide);
			slide.obj.appendTo(this.obj);
		}
		slide.fitToHeight();

		var deleteBtn = $('<button class="delete"><i class="fas fa-times"></i></button>').appendTo(slide.obj);
		deleteBtn.click(()=>{
			//if(window.confirm('Are you sure?')){
				this.removeSlide(slide,true);
			//}
			return false;
		});
		var cloneBtn = $('<button class="clone"><i class="fas fa-plus"></i></button>').appendTo(slide.obj);
		cloneBtn.click(()=>{
			this.clonseSlide(slide);
			return false;
		});
		var editBtn = $('<button class="edit"><i class="fas fa-edit"></i></button>').appendTo(slide.obj);
		editBtn.click(()=>{
			return false;
		});
		
		slide.obj.on("click", ()=>{
			this.selectSlide(slide);
		});
		slide.obj.hide().fadeIn(300, () => {
		});

		//console.log(this.obj.width(),this.obj.scrollLeft(), slide.obj.offset());
		return slide;
	}

	clonseSlide(slide:Slide):Slide {
		if(this._slides.indexOf(slide) == -1) return;
		var clonedSlide:Slide = slide.clone();
		this.addSlide(clonedSlide, this._slides.indexOf(slide));

		setTimeout(()=>{
			this.selectSlide(clonedSlide);
		},50)
		

		return clonedSlide;
	}

	removeSlide(slide:Slide, isAnimation:boolean = false):Slide{
		var index:number = this._slides.indexOf(slide);
		if(index == -1) return;

		var nextSlide:Slide = null;
		if(slide.selected){
			if(index < this._slides.length - 1) {
				nextSlide = this._slides[index + 1];
			}else if(index > 0){
				nextSlide = this._slides[index - 1];
			}
		}


		if(isAnimation){
			this.obj.css("pointer-events","none");
//			slide.obj.css("pointer-events","none");
			slide.obj.fadeOut(300, () => {
				this.obj.css("pointer-events","");
				this._slides.splice(index, 1);

				slide.obj.find("button").remove();
				slide.obj.remove();

				this.selectSlide(nextSlide);
			});
			//slide.obj.animate({"transform":"scale(50%,50%)"}, 300);
		}else{
			this._slides.splice(index, 1);
			slide.obj.find("button").remove();
			slide.obj.remove();
			this.selectSlide(nextSlide);
		}
		return slide;
	}

	private selectSlide(slide:Slide = null){
		this._selectedSlide = undefined;

		$.each(this._slides, (index:number, slide2:Slide) => {
			if(slide2 == slide){
				slide2.selected = true;
				this._selectedSlide = slide2;
			}else{
				slide2.selected = false;
			}
		})
		this.dispatchEvent(new Event("select"));
	}

	//



	//

	get selectedSlide():Slide {
		return this._selectedSlide;
	}

	get isActive():boolean {
		return true;
	}

	get slides():Slide[] {
		return this._slides;
	}
}