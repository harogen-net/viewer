import {Slide} from "./Slide";
import {SlideEditable} from "./SlideEditable";
import {SlideList} from "./SlideList";
import {Image} from "./Image";
import { SlideStorage } from "./utils/SlideStorage";
import { SlideShow } from "./SlideShow";
import { Menu } from "./Menu";


declare var $:any;

export class Viewer {
	
	public static enforceAspectRatio = true;
	public static readonly MODE_SELECT = "mode_select";
	public static readonly MODE_EDIT = "mode_edit";
	public static readonly MODE_SLIDESHOW = "mode_slideshow";

	private canvas:SlideEditable;
	private list:SlideList;
	private slideShow:SlideShow;
	private storage:SlideStorage;
	private menu:Menu;

	private _mode:string;


    constructor(public obj:any){
		$(document).on("drop dragover", (e:any) => {
			e.preventDefault();
			e.stopImmediatePropagation();
		});
		document.addEventListener("webkitfullscreenchange",()=>{
			if(document.webkitFullscreenElement){
				obj.addClass("slideShow");
			}else{
				obj.removeClass("slideShow");
			}
		});

		//
		this.list = new SlideList(obj.find(".list"));
		this.canvas = new SlideEditable(obj.find(".canvas"));
		this.slideShow = new SlideShow($("<div />").appendTo(obj));

		this.storage = new SlideStorage();

		//

		this.list.addEventListener("select", ()=>{
			if(this._mode == Viewer.MODE_SELECT){


			}else if(this._mode == Viewer.MODE_EDIT){
				if(this.list.selectedSlide){
					this.canvas.isActive = true;
					this.list.selectedSlide.isLock = true;
					this.canvas.setData(this.list.selectedSlide.getData());
					this.list.selectedSlide.isLock = false;
				}else{
					this.canvas.initialize();
				}
			}
			//console.log("slide selected at list");
		})
		this.list.addEventListener("edit", ()=>{
			this.setMode(Viewer.MODE_EDIT);
			if(this.list.selectedSlide){
				this.list.selectedSlide.isLock = true;
				this.canvas.setData(this.list.selectedSlide.getData());
				this.list.selectedSlide.isLock = false;
			}
	});
		this.canvas.addEventListener("update",()=>{
			if(this._mode == Viewer.MODE_EDIT){
				if(this.list.selectedSlide){
					this.list.selectedSlide.setData(this.canvas.getData());
				}
			}
		});

		//

		{
			$(".zoomIn").click(() => {
				this.canvas.scale *= 1.1;
			});
			$(".showAll").click(() => {
				this.canvas.scale = SlideEditable.SCALE_DEFAULT;
			});
			$(".zoomOut").click(() => {
				this.canvas.scale /= 1.1;
			});
			
			$(".rotateL").click(() => {
				if(this.canvas.selectedImg) {
					this.canvas.selectedImg.rotation -= 90;
					this.canvas.dispatchEvent(new Event("update"));
				}
			});
			$(".rotateR").click(() => {
				if(this.canvas.selectedImg) {
					this.canvas.selectedImg.rotation += 90;
					this.canvas.dispatchEvent(new Event("update"));
				}
			});
			$(".delete").click(() => {
				if(this.canvas.selectedImg) {
					this.canvas.removeImage(this.canvas.selectedImg);
				}
			});
			$(".copyTrans").click(() => {
				this.canvas.copyTrans();
			});
			$(".pasteTrans").click(() => {
				this.canvas.pasteTrans();
			});
		
			$(".fit").click(() => {
				this.canvas.fitSelectedImage();
			});
		
			$(".save").click(()=>{
				this.storage.save(this.list.slides);
			});
			$(".load").click(()=>{
				if(window.confirm('load slides. Are you sure?')){
					this.list.initialize();
					this.canvas.initialize();
					
					this.storage.load();
					$.each(this.storage.slides, (i:number, slide:Slide)=>{
						this.list.addSlide(slide);
					});
				}
			});
		}
	
		
		$(".startSlideShow").click(() => {
			//$("body").toggleClass("slideShow");
			//list.setMode(SlideList.MODE_SLIDE_SHOW);
			this.slideShow.setUp(this.list.slides);
			this.slideShow.run();
		});
		

	}


	public setMode(mode:string){
		if(mode == this._mode) return;
		this._mode = mode;

		switch(this._mode){
			case Viewer.MODE_SELECT:


			break;
			case Viewer.MODE_EDIT:


			break;
/*			case Viewer.MODE_SLIDESHOW:
			break;*/
		}
	}
}