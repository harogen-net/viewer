import {Slide} from "./Slide";
import {SlideEditable} from "./SlideEditable";
import {SlideList} from "./SlideList";
import {Image} from "./Image";
import { SlideStorage } from "./utils/SlideStorage";
import { SlideShow } from "./SlideShow";
import { Menu } from "./Menu";


declare var $:any;

export class Viewer {
	
	public static enforceAspectRatio = true;
	public static readonly MODE_SELECT = "mode_select";
	public static readonly MODE_EDIT = "mode_edit";
	public static readonly MODE_SLIDESHOW = "mode_slideshow";

	private canvas:SlideEditable;
	private list:SlideList;
	private slideShow:SlideShow;
	private storage:SlideStorage;
	private menu:Menu;

	private _mode:string;


    constructor(public obj:any){
		$(document).on("drop dragover", (e:any) => {
			e.preventDefault();
			e.stopImmediatePropagation();
		});
		document.addEventListener("webkitfullscreenchange",()=>{
			if(document.webkitFullscreenElement){
				obj.addClass("slideShow");
			}else{
				obj.removeClass("slideShow");
			}
		});

		//
		this.list = new SlideList(obj.find(".list"));
		this.canvas = new SlideEditable(obj.find(".canvas"));
		this.slideShow = new SlideShow($("<div />").appendTo(obj));

		this.storage = new SlideStorage();
		this.storage.addEventListener("loaded", (e:any)=>{
			this.list.initialize();
			this.canvas.initialize();
			$.each(this.storage.slides, (i:number, slide:Slide)=>{
				this.list.addSlide(slide);
			});
		});
		//

		this.list.addEventListener("select", ()=>{
			if(this._mode == Viewer.MODE_SELECT){


			}else if(this._mode == Viewer.MODE_EDIT){
				if(this.list.selectedSlide){
					this.canvas.isActive = true;
					this.list.selectedSlide.isLock = true;
					this.canvas.setData(this.list.selectedSlide.getData());
					this.list.selectedSlide.isLock = false;
				}else{
					this.canvas.initialize();
				}
			}
			//console.log("slide selected at list");
		})
		this.list.addEventListener("edit", ()=>{
			this.setMode(Viewer.MODE_EDIT);
			if(this.list.selectedSlide){
				this.list.selectedSlide.isLock = true;
				this.canvas.setData(this.list.selectedSlide.getData());
				this.list.selectedSlide.isLock = false;
			}
		});

		this.canvas.addEventListener("update",()=>{
			if(this._mode == Viewer.MODE_EDIT){
				if(this.list.selectedSlide){
					this.list.selectedSlide.setData(this.canvas.getData());
				}
			}
		});
		this.canvas.addEventListener("close",()=>{
			this.setMode(Viewer.MODE_SELECT);
		});

		//

		{
			$(".zoomIn").click(() => {
				this.canvas.scale *= 1.1;
			});
			$(".showAll").click(() => {
				this.canvas.scale = SlideEditable.SCALE_DEFAULT;
			});
			$(".zoomOut").click(() => {
				this.canvas.scale /= 1.1;
			});
			
			$(".rotateL").click(() => {
				if(this.canvas.selectedImg) {
					this.canvas.selectedImg.rotation -= 90;
					this.canvas.dispatchEvent(new Event("update"));
				}
			});
			$(".rotateR").click(() => {
				if(this.canvas.selectedImg) {
					this.canvas.selectedImg.rotation += 90;
					this.canvas.dispatchEvent(new Event("update"));
				}
			});
			$(".delete").click(() => {
				if(this.canvas.selectedImg) {
					this.canvas.removeImage(this.canvas.selectedImg);
				}
			});
			$(".copyTrans").click(() => {
				this.canvas.copyTrans();
			});
			$(".pasteTrans").click(() => {
				this.canvas.pasteTrans();
			});
		
			$(".fit").click(() => {
				this.canvas.fitSelectedImage();
			});
		
			$(".save").click(()=>{
				if(this.list.slides.length > 0){
					this.storage.save(this.list.slides);
				}
			});
			$(".dispose").click(()=>{
				if($('select.filename').val() == -1) return;
				if(window.confirm('delete selected save data. Are you sure?')){
					this.storage.delete();
				}
			});
			$(".load").click(()=>{
				if($('select.filename').val() == -1) return;
				if(this.list.slides.length > 0){
					if(window.confirm('load slides. Are you sure?')){
						this.storage.load();
					}
				}else{
					this.storage.load();
			}
			});
		}
	
		
		$(".startSlideShow").click(() => {
			//$("body").toggleClass("slideShow");
			//list.setMode(SlideList.MODE_SLIDE_SHOW);
			this.slideShow.setUp(this.list.slides);
			this.slideShow.run();
		});
		
		this.setMode(Viewer.MODE_SELECT);
	}


	public setMode(mode:string){
		if(mode == this._mode) return;
		this._mode = mode;

		switch(this._mode){
			case Viewer.MODE_SELECT:
				this.obj.addClass("select");
				this.obj.removeClass("edit");
				this.canvas.isActive = false;
			break;
			case Viewer.MODE_EDIT:
				this.obj.removeClass("select");
				this.obj.addClass("edit");
				this.canvas.isActive = true;
			break;
/*			case Viewer.MODE_SLIDESHOW:
			break;*/
		}
		this.list.setMode(this._mode);
	}
}