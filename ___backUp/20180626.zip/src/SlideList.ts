import { Slide } from "./Slide";
import {Image} from "./Image";
import { EventDispatcher } from "./events/EventDispatcher";
import { DropHelper } from "./utils/DropHelper";
import { IDroppable } from "./interface/IDroppable";
import { Viewer } from "./Viewer";

declare var $: any;

export class SlideList extends EventDispatcher implements IDroppable {
//	public static readonly MODE_SLIDE_SHOW:string = "SlideList.slideShow";
//	public static readonly MODE_LIST:string = "SlideList.list";

	private _slides:Slide[];
	private _slidesById:any;

	private slideShowTimer:any;
	private slideShowIndex:number;

//	private mode:string = SlideList.MODE_LIST;
	private _mode:string;
	private _selectedSlide:Slide;

	private idBase:number = 1;



	constructor(public obj:any) {
		super();

		//this.obj.on("scroll",()=>{
			//console.log(this.obj.scrollTop(),this.obj.scrollLeft());
		//});

		this.obj.addClass("slideList");
		this.obj.sortable({
			items:".slide",
//			handle:".handle",
//            revert:true,
			scroll:false,
			distance:10,
			cursor:"move",
            tolerance:"pointer",
 //           placeholder:"frame",
			 update:( event, ui )=>{
//				console.log(event,ui);
				this.onSlideSort();
            }

		});
//		this.obj.sortable("disable");

		this._slides = [];
		this._slidesById = {};

 		var dropHelper = new DropHelper(this);
		dropHelper.addEventListener(DropHelper.EVENT_DROP_COMPLETE, (e:CustomEvent)=>{
			var slideObj = $('<div />');
			var slide = new Slide(slideObj);
			//slide.updateSize();
			this.addSlide(slide);
			slide.addImage(new Image(e.detail));
		}); 

		$(window).resize(()=>{
			setTimeout(()=>{
				$.each(this._slides, (index:number, slide:Slide) =>{
					var bool:boolean = slide.selected;
					slide.selected = false;
					slide.fitToHeight();
					slide.updateSize();
					slide.selected = bool;
				})
			},50);

		});
	}

 	setMode(mode:string):void {
		this._mode = mode;
		switch(mode){
			case Viewer.MODE_SELECT:
				$.each(this.slides, (index:number, slide:Slide)=>{
					slide.fitToHeight();
				});
				this.obj.sortable("refresh");
				this.obj.sortable("enable");
			break;
			case Viewer.MODE_EDIT:
				$.each(this.slides, (index:number, slide:Slide)=>{
					slide.fitToHeight();
				});
				this.obj.sortable("disable");
				setTimeout(()=>{
					this.scrollToSelected();
				},300);
		break;
		}
	} 

	initialize():void {
		while(this.slides.length > 0){
			this.removeSlide(this.slides[0]);
		}
	}


	addSlide(slide:Slide,index:number = -1):Slide {
		if(index != -1 && this._slides.length > index){
			this._slides.splice(index + 1,0,slide);
			$.each(this._slides, (index2:number, slide2:Slide) => {
				this.obj.append(slide2);
			});
			this._slides[index].obj.after(slide.obj);
		}else{
			this._slides.push(slide);
			slide.obj.appendTo(this.obj);
		}
		slide.id = Math.floor(Math.random()*10000000);
		this._slidesById[slide.id] = slide;

		slide.fitToHeight();

		var deleteBtn = $('<button class="delete"><i class="fas fa-times"></i></button>').appendTo(slide.obj);
		deleteBtn.click(()=>{
			//if(window.confirm('Are you sure?')){
				this.removeSlide(slide,true);
			//}
			return false;
		});
		var cloneBtn = $('<button class="clone"><i class="fas fa-plus"></i></button>').appendTo(slide.obj);
		cloneBtn.click(()=>{
			this.clonseSlide(slide);
			return false;
		});
		var editBtn = $('<button class="edit"><i class="fas fa-edit"></i></button>').appendTo(slide.obj);
		editBtn.click(()=>{
			this.dispatchEvent(new Event("edit"));
			return false;
		});
		//var sortHandle = $('<button class="handle"><i class="fas fa-arrows-alt"></i></button>').appendTo(slide.obj);
		
		
  		slide.obj.on("click.slide", ()=>{
			this.selectSlide(slide);
		});
		slide.obj.hide().fadeIn(300, () => {
		});

		this.obj.sortable("refresh");

		//console.log(this.obj.width(),this.obj.scrollLeft(), slide.obj.offset());
		return slide;
	}

	clonseSlide(slide:Slide):Slide {
		if(this._slides.indexOf(slide) == -1) return;
		var clonedSlide:Slide = slide.clone();
		this.addSlide(clonedSlide, this._slides.indexOf(slide));

		setTimeout(()=>{
			this.selectSlide(clonedSlide);
		},50)
		

		return clonedSlide;
	}

	removeSlide(slide:Slide, isAnimation:boolean = false):Slide{
		var index:number = this._slides.indexOf(slide);
		if(index == -1) return;

		var nextSlide:Slide = null;
		if(slide.selected){
			if(index < this._slides.length - 1) {
				nextSlide = this._slides[index + 1];
			}else if(index > 0){
				nextSlide = this._slides[index - 1];
			}
		}


		if(isAnimation){
			this.obj.css("pointer-events","none");
//			slide.obj.css("pointer-events","none");
			slide.obj.fadeOut(300, () => {
				this.obj.css("pointer-events","");
				this._slides.splice(index, 1);
				this._slidesById[slide.id] = undefined;
				
				slide.obj.find("button").remove();
				slide.obj.off("click.slide");
				slide.obj.remove();

				this.selectSlide(nextSlide);
			});
			//slide.obj.animate({"transform":"scale(50%,50%)"}, 300);
		}else{
			this._slides.splice(index, 1);
			this._slidesById[slide.id] = undefined;
			slide.obj.find("button").remove();
			slide.obj.off("click.slide");
			slide.obj.remove();
			this.selectSlide(nextSlide);
		}
		return slide;
	}

	private selectSlide(slide:Slide = null){
		this._selectedSlide = undefined;
		$.each(this._slides, (index:number, slide2:Slide) => {
			slide2.obj.off("click.slide");

			if(slide2 == slide){
				slide2.selected = true;
				this._selectedSlide = slide2;

			}else{
				slide2.selected = false;
				slide2.obj.on("click.slide", ()=>{
					this.selectSlide(slide2);
				}); 
			}
		})
		this.dispatchEvent(new Event("select"));
		this.scrollToSelected();
	}

	private scrollToSelected(){
		if(!this._selectedSlide) return;
		switch(this._mode){
			case Viewer.MODE_SELECT:
			//	this.obj.animate({"scrollTop":this._selectedSlide.obj.position().top});
			break;
			case Viewer.MODE_EDIT:
				this.obj.animate({"scrollLeft":this._selectedSlide.obj.position().left + this.obj.scrollLeft() - this.obj.width() / 2 + this._selectedSlide.obj.width() / 2});
			break;
		}
	}

	//

	private onSlideSort() {
		var newSlides:Slide[] = [];

		this.obj.find(".slide").each((i:number, obj:any)=>{
//			console.log(i, $(obj).data("id"));
			newSlides[i] = this._slidesById[$(obj).data("id")];
		});

		this._slides = null;
		this._slides = newSlides;
	}

	//

	get selectedSlide():Slide {
		return this._selectedSlide;
	}

	get isActive():boolean {
		return true;
	}

	get slides():Slide[] {
		return this._slides;
	}
}