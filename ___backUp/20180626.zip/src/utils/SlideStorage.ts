import {Slide} from "../Slide";
import { Image } from "../Image";
import { EventDispatcher } from "../events/EventDispatcher";

declare var $:any;

export class SlideStorage extends EventDispatcher {

	private static readonly SAVE_KEY:string = "viewer.slideData";
	private static readonly DBNAME:string = "viewer";
	private db:any;
	private dbVersion:number;
	private titleStore:any;
	private dataStore:any;

    public slides:Slide[];

    constructor() {
		super();

		let create = ()=>{
			var openReq  = indexedDB.open(SlideStorage.DBNAME);
			openReq.onupgradeneeded = (e:any)=>{
				this.db = e.target.result;
				console.log('db upgrade');
				this.db.createObjectStore("slideTitles", {keyPath:"id",autoIncrement:true});
				this.db.createObjectStore("slideData",{keyPath:"title"});
			}
			openReq.onsuccess = (e:any)=>{
				this.db = e.target.result;
				this.dbVersion = this.db.version;
				console.log('db open success : ' + this.dbVersion);

				var transaction = this.db.transaction(["slideTitles", "slideData"], "readwrite");

				this.titleStore = transaction.objectStore("slideTitles");
				this.dataStore = transaction.objectStore("slideData");
				console.log(this.titleStore, this.dataStore);

				//var putReq = this.titleStore.put({title:"a"});this.titleStore.put({title:"b"});this.titleStore.put({title:"c"});

				//putReq.onsuccess = (e:any)=>{
				//	var getReq = this.titleStore.get(1);
				//	getReq.onsuccess = (e:any)=>{
				//		console.log(e.target.result); // {id : 'A1', name : 'test'}
				//	  }


					  this.updateTitleMenu();

			  //}
			}
			openReq.onerror = (e:any)=>{
				console.log('db open error');
				alert("db open error");
			}
		};


		if(0) {
			var deleteReq = indexedDB.deleteDatabase(SlideStorage.DBNAME);
			deleteReq.onsuccess = (e:any)=>{
				console.log('db delete success');
				create();
			}
		}else{
			create();
		}

    }

    save(slides:Slide[]){

		var titleId:number = parseInt($('select.filename').val());
		var title:string = $('select.filename option:selected').text();

		if(titleId == -1){
			var date = new Date();
			var y = date.getFullYear();
			var m = ("00" + (date.getMonth()+1)).slice(-2);
			var d = ("00" + (date.getDate())).slice(-2);
			var h = ("00" + (date.getHours())).slice(-2);
			var mi = ("00" + (date.getMinutes())).slice(-2);
			var s = ("00" + (date.getSeconds())).slice(-2);
			title = "" + y + m + d + h + mi + s;
		}

		//
		var transaction = this.db.transaction(["slideTitles", "slideData"], "readwrite");

		this.titleStore = transaction.objectStore("slideTitles");
		this.dataStore = transaction.objectStore("slideData");

		var json:any = {};

        var slideData:any[] = [];
        $.each(slides, (i:number, slide:Slide)=>{
            var imageData:any[] = [];
            $.each(slide.getData(), (j:number, datum:any)=>{
                imageData.push(datum);
            });
            slideData.push(imageData);
        });
        json.data = slideData;
        var jsonStr:string = JSON.stringify(json);
		
		var putReq1  = this.titleStore.put({"title":title});
		var putReq2 = this.dataStore.put({title:title, data:jsonStr});
		putReq2.onsuccess = (e:any)=>{
			this.updateTitleMenu();
		}


		
/*         var json:any = {};

        var slideData:any[] = [];
        $.each(slides, (i:number, slide:Slide)=>{
            var imageData:any[] = [];
            $.each(slide.getData(), (j:number, datum:any)=>{
                imageData.push(datum);
            });
            slideData.push(imageData);
        });
        json.data = slideData;
        var jsonStr:string = JSON.stringify(json);
        
        localStorage.setItem(SlideStorage.SAVE_KEY,jsonStr);
        console.log(slideData); */
    }

    public load() {
		this.slides = [];
		var title:string = $('select.filename option:selected').text();
		if(title == "new") return;

		var transaction = this.db.transaction(["slideTitles", "slideData"], "readwrite");
		this.dataStore = transaction.objectStore("slideData");
		var getReq = this.dataStore.get(title);
		getReq.onsuccess = (e:any)=>{
//			console.log(e.target.result); // {id : 'A1', name : 'test'}
			var jsonStr:string = e.target.result.data;
			var json:any = JSON.parse(jsonStr);
			$.each(json.data, (i:number, imageData:any)=>{
//	            console.log(imageData);
	
				var slide:Slide = new Slide($('<div />'));
				$.each(imageData, (j:number, datum:any)=>{
					var imgObj:any = $("<img />");
					imgObj.attr("src",datum.src);
					var img:Image = new Image(imgObj, {
						transX:datum.transX,
						transY:datum.transY,
						scaleX:datum.scaleX,
						scaleY:datum.scaleY,
						rotation:datum.rotation
					});
					img.id = datum.id;
	
					slide.addImage(img);
				});
	
				this.slides.push(slide);
			});

			this.dispatchEvent(new Event("loaded"));
		}


/*         var jsonStr:string = localStorage.getItem(SlideStorage.SAVE_KEY);
        var json:any = JSON.parse(jsonStr);
        $.each(json.data, (i:number, imageData:any)=>{
//            console.log(imageData);

            var slide:Slide = new Slide($('<div />'));
            $.each(imageData, (j:number, datum:any)=>{
                var imgObj:any = $("<img />");
                imgObj.attr("src",datum.src);
                var img:Image = new Image(imgObj, {
                    transX:datum.transX,
                    transY:datum.transY,
                    scaleX:datum.scaleX,
                    scaleY:datum.scaleY,
                    rotation:datum.rotation
                });
                img.id = datum.id;

                slide.addImage(img);
            });

            this.slides.push(slide);
        }); */

	}

	public delete() {
		var title:string = $('select.filename option:selected').text();
		var titleId:number = parseInt($("select.filename").val());
		if(titleId == -1) return;
		var transaction = this.db.transaction(["slideTitles", "slideData"], "readwrite");

		this.titleStore = transaction.objectStore("slideTitles");
		this.dataStore = transaction.objectStore("slideData");

		var deleteReq1  = this.titleStore.delete(titleId);
		var deleteReq2 = this.dataStore.delete(title);
		deleteReq1.onsuccess = (e:any)=>{
			this.updateTitleMenu();
		};
	}
	
	private updateTitleMenu() {
		var newItem = $("select.filename option")[0];
		$("select.filename").empty();
		$("select.filename").append($(newItem));
		this.titleStore.openCursor().onsuccess = function (event) {
			var cursor = event.target.result;
			if (cursor) {
				//console.log(cursor);
				$("select.filename").append('<option value="' + cursor.value.id + '">' + cursor.value.title + '</option>');
				cursor.continue();
			}
		};
	}

}