import {EventDispatcher} from "../events/EventDispatcher";

declare var $:any;

export class ImageManager extends EventDispatcher {
    private static _instance:ImageManager;

    public static get instance():ImageManager {
        if (!this._instance) {
            this._instance = new ImageManager();
        }
        return this._instance;
    }
}