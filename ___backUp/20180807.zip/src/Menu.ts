import { EventDispatcher } from "./events/EventDispatcher";

declare var $:any;

export class Menu extends EventDispatcher {
	constructor(public obj:any){
		super();





		
	}
}