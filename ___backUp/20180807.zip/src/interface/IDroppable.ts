
export interface IDroppable {
    obj:any;
    isActive:boolean;
}