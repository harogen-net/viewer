import {Image} from "./Image";
import {EventDispatcher} from "../events/EventDispatcher";
import { ImageManager } from "../utils/ImageManager";

declare var $: any;

export class Slide extends EventDispatcher {
	static slideFromImage(img:Image):Slide {
		var slide = new Slide($('<div />'));
		slide.addImage(img);

		return slide;
	}

	//

	protected _images:Image[];
	
	public container:any;

	
	private _id:number;
	private scale_min:number = 0.2;
	private scale_max:number = 5;
	protected scale_base:number = 1;
	protected _scale:number = 1;
	protected _selected:boolean = false;

	private _isLock:boolean = false;
	private _durationRatio:number = 1;

	
	constructor(public obj:any){
		super();
		
		this._images = [];

		this.obj.addClass("slide");

		this.container = $('<div class="container" />').appendTo(this.obj);
		this.container.css("width",window.screen.width + "px");
		this.container.css("height",window.screen.height + "px");
		
		this.obj.data

		if(this.obj.width() == 0 && this.obj.height() == 0){
			this.obj.ready(() => {
				this.updateSize();
			});
		}else {
			this.updateSize();
		}
	}

	public addImage(img:Image, index:number = -1):Image {
		if(!img) return img;

		if(this._images.indexOf(img) != -1){
			this._images.splice(this._images.indexOf(img), 1);
		}else {
			this._images.push(img);
		}
		
		this.container.append(img.obj);
		
		if(!img.transform){
			if(img.originHeight > (img.originWidth * 1.2)) {
				img.rotation -= 90;
			}
			this.fitImage(img);
		}
		
		this.setImagesZIndex();
		
		ImageManager.registImage(img);

		return img;
	}

	public removeImage(img:Image):Image {
		if(!img) return img;
		if(this._images.indexOf(img) != -1){
			this._images.splice(this._images.indexOf(img), 1);
		}
		ImageManager.deleteImage(img);
		img.obj.remove();

		this.setImagesZIndex();
		
		return img;
	}

	public removeAllImages() {
		while(this._images.length > 0){
			this.removeImage(this._images[0]);
		}
	}

	//

	get id():number {
		return this._id;
	}
	set id(value:number) {
		this._id = value;
		this.obj.data("id",value);
	}

	get selected(){return this._selected;}
	set selected(value:boolean){
		this._selected = value;
		(this._selected) ? this.obj.addClass("selected") : this.obj.removeClass("selected");
	}
	
	get scale(){return this._scale;}
	set scale(value:number){
		//console.log("init",this._scale, this.scale_base);
		this._scale = value > this.scale_min ? (value < this.scale_max ? value : this.scale_max) : this.scale_min;
		var actualScale:number = this._scale * this.scale_base;
		var containerWidth = window.screen.width * actualScale;
		var containerHeight = window.screen.height * actualScale;
		var defX = -(window.screen.width * (1 - actualScale) / 2) + (this.obj.width() - containerWidth) / 2;
		var defY = -(window.screen.height * (1 - actualScale) / 2) + (this.obj.height() - containerHeight) / 2;
		
		this.container.css("transform","matrix(" + actualScale + ",0,0," + actualScale + "," + defX + "," + defY + ")");
	}
	
	get durationRatio(){return this._durationRatio;}
	set durationRatio(value:number){
		this._durationRatio = value;
		if(this.obj.attr("style")){
			if(this.obj.attr("style").indexOf("width") != -1){
				this.fitToHeight();
			}
		}
/* 		if(parseInt(this.obj.css("width")) > 0){
			this.fitToHeight();
		} */
	}

	//

	public fitToWidth():void {
		var fitHeight = (this.obj.width() / window.screen.width) * window.screen.height;
		//console.log("fitToWidth : ", this.obj.width());
		
		this.obj.css("width","");
		this.obj.height(fitHeight);
		this.scale = this._scale;
	}
	public fitToHeight():void {
		//console.log("fitToHeight : ", this.obj.height());
		this.obj.css("height","");
		var fitWidth = (this.obj.height() / window.screen.height) * window.screen.width * this._durationRatio;

		//animate
		{
			if(this.obj.attr("style") && this.obj.attr("style").indexOf("width") != -1){
				this.obj.animate({"width":fitWidth},{duration :200,step:()=>{
					this.scale = this._scale;
				}});
			}else{
				this.obj.width(fitWidth);
				this.scale = this._scale;
			}
		}
		//this.obj.width(fitWidth);
		//this.scale = this._scale;
	}
	public updateSize():void {
		this.scale_base = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height);
		//console.log(this.obj.width(), this.obj.height(), window.screen.width, window.screen.height, this.scale_base, this._scale);
		this.scale = this._scale;
	}
	
	public fitImage(img:Image):Image {
		var scaleX,scaleY;
		if(img.rotation == 90 || img.rotation == -90){
			scaleX = window.screen.width / img.height;
			scaleY = window.screen.height / img.width;
		}else{
			scaleX = window.screen.width / img.width;
			scaleY = window.screen.height / img.height;
		}
		img.scale = Math.min(scaleX, scaleY);
		img.x = window.screen.width >> 1;
		img.y = window.screen.height >> 1;
		return img;
	}

	//

	public clone():Slide {
		var newObj:any = $('<div />');
		var slide:Slide = new Slide(newObj);
		slide.id = this.id;
		$.each(this._images, (index:number, image:Image) => {
			slide.addImage(image.clone());
		});
		slide.durationRatio = this._durationRatio;

		return slide;
	}

	//

	getData():any[] {
		var ret:any[] = [];
		$.each(this._images, (index:number,img:Image) => {
			ret.push(img.data);
		});
		return ret;
	}

	setData(aData:any[]){
		if(this._isLock) return;

		var i,j:number;
		var img:Image;
		var datum:{class:Image};
		var found:boolean;
		var newImages:Image[] = [];

//		console.log(this.id, "=============");
//		console.log("処理前 : ", this._images.length, aData.length);
		$.each(aData, (i, datum) => {
			found = false;
			$.each(this._images, (j, img) => {
				if(datum.class.imageId == img.imageId){
					img.transform = datum.class.transform;
					found = true;
					newImages[i] = img;
				}
			});
			if(!found){
				//console.log("\t",datum.class.imageId.slice(0,8) + "～のImageがありません");
				newImages[i] = this.addImage(datum.class.clone());
			}
		});

		for(i = 0; i < this._images.length; i++){
			img = this._images[i];
			found = false;
			$.each(aData, (j, datum) => {
				if(datum.class.imageId == img.imageId) {
					found = true;
				}
			});
			if(!found){
				//console.log("\t", img.imageId.slice(0,8) + "～のImageが不必要です");
				this.removeImage(img);
				i--;
			}
		}

		this._images = newImages;
//		console.log(this.id, "/=============");
		this.setImagesZIndex();
	}

	get images():Image[]{
		return this._images.concat();
	}

	set isLock(value:boolean){
		this._isLock = value;
	}
	get isLock():boolean{
		return this._isLock;
	}

	//

	protected setImagesZIndex(){
		for(var i = 0; i < this._images.length; i++){
			this._images[i].obj.css("z-index",i);
		}
	}
}