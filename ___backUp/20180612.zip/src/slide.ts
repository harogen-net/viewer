import {Image} from "./image.ts";

declare var $: any;
//declare var Matrix4: any;


export class Slide{

	protected images:any[];
	
	protected _scale:number = 1;
	
	public container:any;
	public id:number;
	public obj:any;
	
	private scale_min:number;
	private scale_max:number;
	
	
	constructor(id:number, obj:any){
		this.id = id;
		this.obj = obj;
		this.container = $('<div class="container" />').appendTo(this.obj);
		
		this.images = [];
		
		this.container.css("width",window.screen.width + "px");
		this.container.css("height",window.screen.height + "px");
		
		this.scale_min = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 0.5;
		this.scale_max = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 2;
		this.showAll();
		
		
		$(window).on("resize", (e:any) => {
			this.scale_min = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 0.5;
			this.scale_max = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 2;
		});
	}
	
	public addImage(img:Image):Image {
		if(!img) return img;
		if(this.images.indexOf(img) != -1){
			this.images.splice(this.images.indexOf(img), 1);
		}else {
			this.images.push(img);
		}
		
		this.container.append(img.obj);
		
		if(!img.transform){
			this.fitImage(img);
		}
		
		return img;
	}
	public removeImage(img:Image):Image {
		if(!img) return img;
		if(this.images.indexOf(img) != -1){
			this.images.splice(this.images.indexOf(img), 1);
		}
		img.obj.remove();
		
		return img;
	}
	
	get scale(){return this._scale;}
	set scale(value:number){
		this._scale = value > this.scale_min ? (value < this.scale_max ? value : this.scale_max) : this.scale_min;
		
		var containerWidth = window.screen.width * value;
		var containerHeight = window.screen.height * value;
		var defX = -(window.screen.width * (1 - value) / 2) + (this.obj.width() - containerWidth) / 2;
		var defY = -(window.screen.height * (1 - value) / 2) + (this.obj.height() - containerHeight) / 2;
		
		this.container.css("transform","matrix(" + this._scale + ",0,0," + this._scale + "," + defX + "," + defY + ")");
	}
	
	public fitToWidth():void {
		var fitHeight = (this.obj.width() / window.screen.width) * window.screen.height;
		this.obj.height(fitHeight);
		this.scale = this.obj.width() / window.screen.width;
	}
	public fitToHeight():void {
		var fitWidth = (this.obj.height() / window.screen.height) * window.screen.width;
		this.obj.width(fitWidth);
		this.scale = this.obj.height() / window.screen.height;
	}
	public showAll():void {
		this.scale = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height);
	}
	
	public fitImage(img:Image):Image {
		var scaleX = window.screen.width / img.width;
		var scaleY = window.screen.height / img.height;
		img.scale = Math.min(scaleX, scaleY);
		img.x = window.screen.width >> 1;
		img.y = window.screen.height >> 1;
		
		return img;
	}
	
	get data() {
		var ret:any[] = [];
		$.each(this.images, (index:number,img:Image) => {
			ret.push(img.data);
		});
		
		console.log(ret);
		return ret;
	}
}