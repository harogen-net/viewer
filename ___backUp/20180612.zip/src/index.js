'use strict';


import {Slide} from "./slide.ts";
import {SlideEditable} from "./slideEditable.ts";
import {Image} from "./image.ts";

var enforceAspectRatio = true;




var canvas;

$(function(){
	console.log("init");
	

	$(".canvas").each((i, obj) => {
		canvas = new SlideEditable(i, $(obj));
		
		
		var img = $('<img src="img/test.png"/>');
		img.bind("load",()=>{
			img.unbind("load");
			$(obj).append(img);
			img.ready(()=>{
				canvas.addImage(new Image(img));
			})
		});
		
	});
	
	$(".zoomIn").click(() => {
		canvas.scale *= 1.1;
	});
	$(".showAll").click(() => {
		canvas.showAll();
	});
	$(".zoomOut").click(() => {
		canvas.scale /= 1.1;
	});
	
	$(".rotateL").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation -= 90;
		}
	});
	$(".rotateR").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation += 90;
		}
	});
	$(".delete").click(() => {
		if(canvas.selectedImg) {
			canvas.removeImage(canvas.selectedImg);
		}
	});
	$(".copyTrans").click(() => {
		canvas.copyTrans();
	});
	$(".pasteTrans").click(() => {
		canvas.pasteTrans();
	});
	$(".data").click(() => {
		var data = canvas.data;
	});
	$(".fit").click(() => {
		canvas.fitSelectedImage();
	});
/* 	canvas.addImage(new Image(0, $('<img src="img/test.png" width="200">')));
	canvas.addImage(new Image(1, $('<img src="img/test.png" width="200">')));
 */	
	
/*	$("#canvas").find("img").each(function(index, value){
		var img = new Image(index,$(value));
		images.push(img);
		
		img.obj.on("dragstart", (e,ui) => {
			//console.log("dragStart : " + ui);
			
		});
		img.obj.on("dragstop", (e,ui) => {
			//console.log("dragstop : " + this.id);
		});
		img.obj.on("click", (e) => {
			selectImage(img);
		});
	})*/
	
/*	$("#canvas").find("img").on("click", function(obj){
		
		var targetImg = $(this);
		
		if(!selectedImg){
			selectedImg = targetImg;
			selectedImg.addClass("selected");
		}else{
			if(selectedImg == targetImg){
				unselectAll();
			}else{
				unselectAll();
				selectedImg = targetImg;
				selectedImg.addClass("selected");
			}
		}
		console.log(selectedImg.attr("src"));
		
	});*/
/* 	$("#canvas").find("img").on("click", function(obj){
		console.log(obj.target);
	}); */
	
	
	

	
});




function distance(x1,y1,x2,y2){
	return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	
}