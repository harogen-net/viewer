'use strict';


import {*} from ".image.ts";

var enforceAspectRatio = true;

var input_key_buffer = new Array();
document.onkeydown = function (e){
	if(!e) e = window.event; // レガシー
	input_key_buffer[e.keyCode] = true;
};
document.onkeyup = function (e){
	if(!e) e = window.event; // レガシー
	input_key_buffer[e.keyCode] = false;
};


var canvas;

$(function(){
	console.log("init");
	
/* 	var images = [];
	var selectedImg = null;
 */	
 
//	var canvas = new slideEditable(0, $(".canvas"));

	$(".canvas").each((i, obj) => {
		canvas = new SlideEditable(i, $(obj));
		
		
		var img = $('<img src="img/test.png"/>');
		img.bind("load",()=>{
			img.unbind("load");
			$(obj).append(img);
			img.ready(()=>{
				canvas.addImage(new Image(img));
			})
		});
		
	});
	
	$(".zoomIn").click(() => {
		canvas.scale *= 1.1;
	});
	$(".showAll").click(() => {
		canvas.showAll();
	});
	$(".zoomOut").click(() => {
		canvas.scale /= 1.1;
	});
	
	$(".rotateL").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation -= 90;
		}
	});
	$(".rotateR").click(() => {
		if(canvas.selectedImg) {
			canvas.selectedImg.rotation += 90;
		}
	});
	$(".delete").click(() => {
		if(canvas.selectedImg) {
			canvas.removeImage(canvas.selectedImg);
		}
	});
	$(".copyTrans").click(() => {
		canvas.copyTrans();
	});
	$(".pasteTrans").click(() => {
		canvas.pasteTrans();
	});
	$(".data").click(() => {
		var data = canvas.data;
	});
	$(".fit").click(() => {
		canvas.fitSelectedImage();
	});
/* 	canvas.addImage(new Image(0, $('<img src="img/test.png" width="200">')));
	canvas.addImage(new Image(1, $('<img src="img/test.png" width="200">')));
 */	
	
/*	$("#canvas").find("img").each(function(index, value){
		var img = new Image(index,$(value));
		images.push(img);
		
		img.obj.on("dragstart", (e,ui) => {
			//console.log("dragStart : " + ui);
			
		});
		img.obj.on("dragstop", (e,ui) => {
			//console.log("dragstop : " + this.id);
		});
		img.obj.on("click", (e) => {
			selectImage(img);
		});
	})*/
	
/*	$("#canvas").find("img").on("click", function(obj){
		
		var targetImg = $(this);
		
		if(!selectedImg){
			selectedImg = targetImg;
			selectedImg.addClass("selected");
		}else{
			if(selectedImg == targetImg){
				unselectAll();
			}else{
				unselectAll();
				selectedImg = targetImg;
				selectedImg.addClass("selected");
			}
		}
		console.log(selectedImg.attr("src"));
		
	});*/
/* 	$("#canvas").find("img").on("click", function(obj){
		console.log(obj.target);
	}); */
	
	
	

	
});



class Image{
	
	/*static imageFromSrcAndMatrix(src, matrix){
		 var reader = new FileReader();
		reader.addEventListener('load', (e) => {
			return new Image($('<img src="' + reader.result + '" />'), matrix);
		});
		reader.readAsDataURL(src);
	}
	
	static imageFromBlob(blob){
		var reader = new FileReader();
		reader.addEventListener('load', (e) => {
			console.log(e);
			return new Image($('<img src="' + reader.result + '" />'));
		});
		reader.readAsDataURL(blob);
	}*/
	
	constructor(imgObj, transform){
		this.originWidth = imgObj.width();
		this.originHeight = imgObj.height();
		if(this.originWidth == 0 || this.originHeight == 0){
			throw new Error();
		}
		
		this.obj = $('<div class="imgWrapper" />');
		this.obj.append(imgObj);
		this.img = imgObj;
		
		
//		this.obj = obj;
		if(transform){
			//this.matrix = matrix;
			this.transform = transform;
		}else{
			this._transX = 0;
			this._transY = 0;
			this._scaleX = 1;
			this._scaleY = 1;
			this._rotation = 0;
			this.updateMatrix();
		}
		
		this._selected = false;
		this._editable = false;
		
		//
		
		
//		console.log(this.center);
		
//		this.obj.draggable().css("position", "absolute");
//		this.obj.draggable('disable');
	}
	
	get selected(){ return this._selected;}
	set selected(value){
		this._selected = value;
		
/* 		if(this._selected){
			this.obj.addClass("selected");
			this.obj.draggable("enable");
		}else{
			this.obj.removeClass("selected");
			this.obj.draggable('disable');
		} */
	}
	
 	get x(){
		return (this.originWidth / 2) + this._transX;
	}
	set x(value){
		this._transX = value - (this.originWidth / 2);
		this.updateMatrix();
	}
	get y(){return (this.originHeight / 2) + this._transY;}
	set y(value){
		this._transY = value  - (this.originHeight / 2);
		this.updateMatrix();
	}
	get scale(){
		if(this._scaleX == this._scaleY) return this._scaleX;
		return NaN;
	}
	set scale(value){
		this._scaleX = value;
		this._scaleY = value;
		this.updateMatrix();
	}
	get scaleX(){return this._scaleX;}
	set scaleX(value){
		this._scaleX = (value > 0.1) ? value : 0.1;
		this.updateMatrix();
	}
	get scaleY(){return this._scaleY;}
	set scaleY(value){
		this._scaleY = (value > 0.1) ? value : 0.1;
		this.updateMatrix();
	}
	get rotation(){return this._rotation;}
	set rotation(value){
		this._rotation = value % (360);
		
		this.updateMatrix();
	}
	get width(){
		return this.obj.width()// * this._scaleX;
	}
	get height(){
		return this.obj.height()// * this._scaleY;
	}
 	get diagonalAngle(){
		return Math.atan2(this,height, this.width);
	}
	
	moveBy(x,y){
		this._transX += x;
		this._transY += y;
//		this._matrix = Matrix4.translation(x,y,0).mulByMatrix4(this._matrix);
//		this._matrix = this._matrix.translate(x,y,0);
		this.updateMatrix();
	}
 	scaleBy(scaleX, scaleY){
		this._scaleX *= scaleX;
		this._scaleY *= scaleY;
		//this._matrix = Matrix4.scaling(scaleX,scaleY,1).mulByMatrix4(this._matrix);
//		this._matrix = this._matrix.scale(scaleX,scaleY,1);
		this.updateMatrix();
	}
	rotateBy(theta){
		//this._matrix = Matrix4.rotationZ(theta).mulByMatrix4(this._matrix);
		//this._matrix = this._matrix.rotateZ(theta);
		this._rotation += theta * 180 / Math.PI;
		this.updateMatrix();
	}
	updateMatrix(){
		this._matrix = Matrix4.identity().translate(this._transX, this._transY,0).rotateZ(this._rotation * Math.PI / 180).scale(this._scaleX,this._scaleY,1);
		var cssMat = "matrix("
			+ this._matrix.values[0] + ","
			+ this._matrix.values[1] + ","
			+ this._matrix.values[4] + ","
			+ this._matrix.values[5] + ","
			+ this._matrix.values[12] + ","
			+ this._matrix.values[13]
			+ ")";
		this.obj.css("transform", cssMat);
	}
	
	get center(){
		//var tmpMat = this._matrix.translate(-this.obj.width() / 2, -this.obj.height() / 2, 0);
//		var tmpMat = this._matrix.translate(100, 44, 0);
		
		return {x:this._matrix.values[12] + this.width / 2, y:this._matrix.values[13] + this.height / 2};
	}
	
	get transform(){
		if(this._transX == 0 && this._transY == 0 && this._scaleX == 1 && this._scaleY == 1 && this._rotation == 0) {
			return null;
		}
		return {
			transX:this._transX,
			transY:this._transY,
			scaleX:this._scaleX,
			scaleY:this._scaleY,
			rotation:this._rotation
		};
	}
	set transform(value){
		if(!value) throw new Error("");
		
		this._transX = value.transX || 0;
		this._transY = value.transY || 0;
		this._scaleX = value.scaleX || 1;
		this._scaleY = value.scaleY || 1;
		this._rotation = value.rotation || 0;
		
		this.updateMatrix();
	}
	
	get data(){
		return {
			src:this.img.attr("src"),
			transX:this._transX,
			transY:this._transY,
			scaleX:this._scaleX,
			scaleY:this._scaleY,
			rotation:this._rotation
		}
	}
	
}

class Slide{
	constructor(id, obj){
		this.id = id;
		this.obj = obj;
		this.container = $('<div class="container" />').appendTo(this.obj);
		
		this.images = [];
		
		this._scale = 1;
		this.container.css("width",window.screen.width + "px");
		this.container.css("height",window.screen.height + "px");
		
		this.scale_min = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 0.5;
		this.scale_max = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 2;
		this.showAll();
		
		
		$(window).on("resize", (e) => {
			this.scale_min = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 0.5;
			this.scale_max = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height) * 2;
		});
	}
	
	addImage(img){
		if(!img) return;
		if(this.images.indexOf(img) != -1){
			this.images.splice(this.images.indexOf(img), 1);
		}else {
			this.images.push(img);
		}
		
		this.container.append(img.obj);
		
		if(!img.transform){
			this.fitImage(img);
		}
	}
	removeImage(img){
		if(!img) return;
		if(this.images.indexOf(img) != -1){
			this.images.splice(this.images.indexOf(img), 1);
		}
		img.obj.remove();
	}
	
	get scale(){return this._scale;}
	set scale(value){
		this._scale = value > this.scale_min ? (value < this.scale_max ? value : this.scale_max) : this.scale_min;
		
		var containerWidth = window.screen.width * value;
		var containerHeight = window.screen.height * value;
		var defX = -(window.screen.width * (1 - value) / 2) + (this.obj.width() - containerWidth) / 2;
		var defY = -(window.screen.height * (1 - value) / 2) + (this.obj.height() - containerHeight) / 2;
		
		this.container.css("transform","matrix(" + this._scale + ",0,0," + this._scale + "," + defX + "," + defY + ")");
	}
	
	fitToWidth(){
		var fitHeight = (this.obj.width() / window.screen.width) * window.screen.height;
		this.obj.height(fitHeight);
		this.scale = this.obj.width() / window.screen.width;
	}
	fitToHeight(){
		var fitWidth = (this.obj.height() / window.screen.height) * window.screen.width;
		this.obj.width(fitWidth);
		this.scale = this.obj.height() / window.screen.height;
	}
	showAll(){
		this.scale = Math.min(this.obj.width() / window.screen.width, this.obj.height() / window.screen.height);
	}
	
	fitImage(img){
		var scaleX = window.screen.width / img.width;
		var scaleY = window.screen.height / img.height;
		img.scale = Math.min(scaleX, scaleY);
		img.x = window.screen.width >> 1;
		img.y = window.screen.height >> 1;
	}
	
	get data(){
		var ret = [];
		$.each(this.images, (index,img) => {
			ret.push(img.data);
		});
		
		console.log(ret);
		return ret;
	}
}

class SlideEditable extends Slide {
	constructor(id, obj){
		super(id, obj);
		
		this.selectedImg = null;
		
		this.obj.addClass("editable");
		
		
		//this.shadow = $('<div class="shadow" />').appendTo(this.obj);
		this.border = $('<div class="border" />').appendTo(this.container);

		
		this.controls = $('<div class="controls">');
		this.frame = $('<div class="frame" />').appendTo(this.controls);
		this.anchorPoint1 = $('<div class="anchor ne" />').appendTo(this.controls);
		this.anchorPoint1.on("mousedown.image", (e) => {
			this.startScale(e,"ne");
			e.stopImmediatePropagation();
		});
		this.anchorPoint2 = $('<div class="anchor nw" />').appendTo(this.controls);
		this.anchorPoint2.on("mousedown.image", (e) => {
			this.startScale(e,"nw");
			e.stopImmediatePropagation();
		});
		this.anchorPoint3 = $('<div class="anchor se" />').appendTo(this.controls);
		this.anchorPoint3.on("mousedown.image", (e) => {
			this.startScale(e,"se");
			e.stopImmediatePropagation();
		});
		this.anchorPoint4 = $('<div class="anchor sw" />').appendTo(this.controls);
		this.anchorPoint4.on("mousedown.image", (e) => {
			this.startScale(e,"sw");
			e.stopImmediatePropagation();
		});
		
		this.frame.on("mousedown.image_drag", (e) => {
			this.startDrag(e);
			e.stopImmediatePropagation();
		});
		
		this.mouseX = 0;
		this.mouseY = 0;
		this.isDrag = false;
		//console.log(this.frame);
		
		$(document).on("wheel", (e) => {
			console.log(input_key_buffer[17])
			if(input_key_buffer[17]){
				var dScale = (0.1 * e.originalEvent.deltaY / Math.abs(e.originalEvent.deltaY));
				this.scale /= (1 + dScale);
				e.preventDefault();
				e.stopImmediatePropagation();
			}
			
			
			return;
			
			if(!this.selectedImg) return;
			
			var theta = (e.originalEvent.deltaY / 20) * (Math.PI / 180);
			if(input_key_buffer[16]){
				theta = (45 * e.originalEvent.deltaY / Math.abs(e.originalEvent.deltaY)) * (Math.PI / 180);
			}
			this.selectedImg.rotateBy(theta);
			//this.selectedImg.rotation = 45;
		});
		this.obj.on("mousedown",(e) => {
			//console.log("mousedown");
			this.selectImage();
		});
		
		//this.imageLoader = new ImageLoader(this);
		
		this.obj.on("dragover", (e) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			this.obj.addClass("fileOver");
		});
		this.obj.on("dragleave", (e) => {
			this.obj.removeClass("fileOver");
		});
		this.obj.on("drop", (e) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			this.obj.removeClass("fileOver");
			
			$.each(e.originalEvent.dataTransfer.files, (index, file) => {
				var reader = new FileReader();
				reader.addEventListener('load', (e) => {
					
					var imgObj = $('<img src="' + reader.result + '" />');
					imgObj.bind("load",()=>{
						imgObj.unbind("load");
						$("body").append(imgObj);
						imgObj.ready(()=>{
							canvas.addImage(new Image(imgObj));
						})
					});

				});
				reader.readAsDataURL(file);
			});
		});
		
		
		
		
		
		this.transClip = null;
	}
	
	addImage(img){
		super.addImage(img);
		
/* 		img.obj.off("dblclick.image");
		img.obj.on("dblclick.image", (e) => {
			this.selectImage(img);
		}); */
		img.obj.on("mousedown.image_preselect", (e) => {
			if(img.selected) return;
			
			img.obj.off("mousemove.image_preselect");
			img.obj.on("mousemove.image_preselect", (e) => {
				img.obj.off("mousemove.image_preselect");
				this.selectImage(img);
				this.startDrag(e);
			});
			e.stopImmediatePropagation();
		});
		img.obj.on("mouseup.image_preselect", (e) => {
			img.obj.off("mousemove.image_preselect");
			if(!img.selected && !this.isDrag){
				this.selectImage(img);
			};
		});
	}
	
	removeImage(img){
		if(img == this.selectedImg){
			this.selectImage();
		}
		
		super.removeImage(img);
		
		img.obj.off("dragstart");
		img.obj.off("mousedown.image_preselect");
		img.obj.off("mousemove.image_preselect");
		img.obj.off("mouseup.image_preselect");
	}
	
	selectImage(img){
/* 		if(img){
			console.log("selectImage : ", img.id)
		}else {
			 console.log("unselectImage");
		} 
 */		
		if(this.selectedImg) {
			this.controls.detach();
		}
		this.selectedImg = null;

		$.each(this.images, (i,value) => {
			if(img == value){
				value.selected = true;
				
				this.selectedImg = value;
			}else {
				value.selected = false;
			}
		});
		
		if(this.selectedImg){
			this.selectedImg.obj.append(this.controls);
/*			this.controls.css("width",(this.selectedImg.width));
			this.controls.css("height",(this.selectedImg.height));*/
			this.updateControlsSize();
			
			this.controls.show();
		}else{
			this.controls.hide();
		}
	}
	
	setImageIndex(){
		
	}
	
	startDrag(e){
		if(!this.selectedImg) return;
		//if(this.isDrag) this.stopDrag(e);
		this.isDrag = true;
		
		var mouseX = e.screenX;
		var mouseY = e.screenY;
		
		$(document).off("mousemove.image_drag");
		$(document).off("mouseup.image_drag");
		$(document).on("mousemove.image_drag", (e) => {
			if(!this.selectedImg) return;
			if(!this.isDrag) return;
			
			this.selectedImg.moveBy((e.screenX - mouseX) / this._scale, (e.screenY - mouseY) / this._scale);
			mouseX = e.screenX;
			mouseY = e.screenY;
		});
		$(document).on("mouseup.image_drag", (e) => {
			if(!this.selectedImg) return;
			if(!this.isDrag) return;
			
			this.isDrag = false;
			$(document).off("mousemove.image_drag");
			$(document).off("mouseup.image_drag");
		});
	}
	
	startScale(e,key){
		if(!this.selectedImg) return;
		if(this.isDrag) this.stopScale(e);
		this.isDrag = true;
		
		var mouseX = e.screenX;
		var mouseY = e.screenY;
		
		var controlX = (this.selectedImg.width / 2) * (this.selectedImg.scaleX);
		var controlY = (this.selectedImg.height / 2) * (this.selectedImg.scaleY);
		
		$(document).off("mousemove.image_scale");
		$(document).off("mouseup.image_scale");
		$(document).on("mousemove.image_scale", (e) => {
			if(!this.isDrag) return;
			
			var defX,defY = 0;
			switch(key){
				case "ne":
					defX = (e.screenX - mouseX);
					defY = (e.screenY - mouseY);
				break;
				case "nw":
					defX = (mouseX - e.screenX);
					defY = (e.screenY - mouseY);
				break;
				case "se":
					defX = (e.screenX - mouseX);
					defY = (mouseY - e.screenY);
				break;
				case "sw":
					defX = (mouseX - e.screenX);
					defY = (mouseY - e.screenY);
				break;
				default:
				break;
			}
			defX /= this._scale;
			defY /= this._scale;
			
			var mat = Matrix4.identity().rotateZ(this.selectedImg.rotation * Math.PI / 180).translate(defX, -defY,0);
			var defX2 = mat.values[12];
			var defY2 = mat.values[13];
			
			var scaleX = (controlX + defX2) / (this.selectedImg.width / 2);
			var scaleY = (controlY + defY2) / (this.selectedImg.height / 2);
			
			if(input_key_buffer[16] || enforceAspectRatio) {
				var scale = Math.min(scaleX, scaleY);
				this.selectedImg.scaleX = this.selectedImg.scaleY = scale;
			}else{
				this.selectedImg.scaleX = scaleX;
				this.selectedImg.scaleY = scaleY;
			}
			
			this.updateControlsSize();
		});
		$(document).on("mouseup.image_scale", (e) => {
			if(!this.isDrag) return;
			this.isDrag = false;
			$(document).off("mousemove.image_scale");
			$(document).off("mouseup.image_scale");
		});
	}
	
	updateControlsSize(){
		if(this.border){
			this.border.css("border-width", 10/this._scale + "px");
		}
		
		if(!this.selectedImg) return;
		var anchorSizeX = 20 / (this.selectedImg.scaleX * this._scale);
		var anchorSizeY = 20 / (this.selectedImg.scaleY * this._scale);
		this.anchorPoint1.css("width",anchorSizeX);
		this.anchorPoint1.css("height",anchorSizeY);
		this.anchorPoint2.css("width",anchorSizeX);
		this.anchorPoint2.css("height",anchorSizeY);
		this.anchorPoint3.css("width",anchorSizeX);
		this.anchorPoint3.css("height",anchorSizeY);
		this.anchorPoint4.css("width",anchorSizeX);
		this.anchorPoint4.css("height",anchorSizeY);
		var borderSizeH = 3 / (this.selectedImg.scaleX * this._scale) + "px";
		var borderSizeV = 3 / (this.selectedImg.scaleY * this._scale) + "px";
		this.frame.css("border-width",borderSizeV + " " + borderSizeH);
	}
	
	copyTrans(){
		if(!this.selectedImg) return;
		this.transClip = this.selectedImg.transform;
	}
	
	pasteTrans(){
		if(!this.selectedImg) return;
		if(!this.transClip) return;
		this.selectedImg.transform = this.transClip;
		console.log(this.selectedImg.transform, this.transClip);
		this.updateControlsSize();
	}
	
	showAll(){
		super.showAll();
		this.updateControlsSize();
	}
	
	fitSelectedImage(){
		if(!this.selectedImg) return;
		this.selectedImg.rotation = 0;
		this.fitImage(this.selectedImg);
		this.updateControlsSize();
	}

}
/*
class ImageLoader{
	constructor(target){
		this.target = target;
		
		target.obj.on("dragover", (e) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			
			target.obj.addClass("fileOver");
		});
		target.obj.on("dragleave", (e) => {
			target.obj.removeClass("fileOver");
		});
		target.obj.on("drop", (e) => {
			e.preventDefault();
			e.stopImmediatePropagation();
			
			target.obj.removeClass("fileOver");
			
			this.loadFromFiles(e.originalEvent.dataTransfer.files);
		});
	}
	
	loadFromFiles(files){
		if(!files) return;
		if(!files.length) return;
		
		$.each(files, (index, file) => {
			 var reader = new FileReader();
			reader.addEventListener('load', (e) => {
				//console.log(e);
				
				//var event = new CustomEvent("imageLoaded", {image:img});
				this.target.addImage(new Image(reader.result));
			});
			reader.readAsDataURL(file);
			
		});
	}
	
	destroy(){
	}
}
*/

function distance(x1,y1,x2,y2){
	return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	
}